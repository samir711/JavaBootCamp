public class Variables {

    public static void main(String[] args){
        System.out.println("Hello");


        int marioScore = 200;
        int lifeUps = 5;

        int finalMarioScore = marioScore * lifeUps;

        System.out.println(finalMarioScore);



    }

}
