public class BOABank extends Banker {

    public BOABank(String name, String tax, double balance) {
        super(name, tax, balance);
    }



}
