public class Main {
    public static void main(String[] args){

        //Banker john = new Banker(); //Not allowed
    }

    
}
