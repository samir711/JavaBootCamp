public class Logical {

    public static void main(String args[]){

        boolean fbLogin = true;
        boolean googleLogin = false;
        boolean email = false;
        //boolean hasPaid = false;

        //&& - returns true if both/all conditions are true
//        System.out.println( hasAccount && isLoggedIn && hasPaid);

        //|| - Returns True if any one of them is true
//        System.out.println( fbLogin || googleLogin || email);

        // ! - reverse things
        System.out.println(!email);

    }
}
