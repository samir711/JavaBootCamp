public class BankUser {

    public static void main(String args[]){

//        BankApp John = new BankApp("John Doe");
//
//        John.accAge(45);
//        John.depositAmount(100000);
//
//        John.getUserInfo();
//
//
//        BankApp Jane = new BankApp("Jane Doe");
//        Jane.accAge(25);
//        Jane.depositAmount(300000);
//
//        Jane.getUserInfo();
//
//
//        John.depositAmount(200);
//
//        Jane.depositAmount(50000);
//
//        Jane.getUserInfo();
//
//        John.getUserInfo();



        //Inheritance starts here:


        SbiUser ram = new SbiUser("ram");

        ram.depositAmount(30);
        //ram.accTax("MyTaxInfo");


        ram.getUserInfo();




    }

    


}
