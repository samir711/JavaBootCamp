public class Arithmetic {


    public static void main(String args[]){

        int number1 = 10;
        int number2 = 20;
        int number3 = 35;


        System.out.println(number3 % number1);

//        number1 = number1 + 1;

//        number1++;

        System.out.println(number1++);
        System.out.println(number1);

        System.out.println(++number1);


    }

}
