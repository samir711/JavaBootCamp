public class IfElse {

    public static void main(String args[]){

        int temp = 35;

        if ((temp < 30) || (temp < 40) ){
            System.out.println("Temp is less than 30");
            System.out.println("its cool");
        }
//        if (temp < 40) {
//            System.out.println("Temp is less than 40");
//        }
        else {
            System.out.println("Temp is HOT");
        }

       


    }
}
