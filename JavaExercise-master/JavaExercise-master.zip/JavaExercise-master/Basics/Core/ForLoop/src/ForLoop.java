public class ForLoop {

    public static void main(String args[]){
//
//        for (init; condition; incre/decri){
//
//        }
//

        for (int myVariable = 1; myVariable < 100; myVariable = myVariable + 1){
            System.out.println(myVariable);
        }


    }
}
