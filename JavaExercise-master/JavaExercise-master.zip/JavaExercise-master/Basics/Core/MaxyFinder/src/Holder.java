public class Holder<T> {

    private T myVar;

    public T getMyVar() {
        return myVar;
    }

    public void setMyVar(T myVar) {
        this.myVar = myVar;
    }
}
