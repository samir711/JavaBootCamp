public class Assignment {

    public static void main(String args[]){

        int number1 = 10;
        int number2 = 5;

        int number3 = 100;

        number3  = number3 + number1;
        number3 += number1;

        System.out.println(number3);

        System.out.println( ((7+7)-10)*(3/6) );




    }
}
