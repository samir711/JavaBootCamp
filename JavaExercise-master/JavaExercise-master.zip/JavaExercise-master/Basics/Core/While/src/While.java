public class While {

    public static void main(String args[]){

        //While Loop

        int myVariable = 1;
//
        while(myVariable <= 10) {
            System.out.println(myVariable);
            myVariable++;
        }

//
        System.out.println("I am out of loop");

        //Do While Loop

//        do{
//            System.out.println(myVariable);
//            myVariable++;
//
//        } while(myVariable < 10);
//





    }
}








