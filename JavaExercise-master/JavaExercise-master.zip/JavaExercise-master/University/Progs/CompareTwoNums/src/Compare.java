public class Compare {

    public static void main(String args[]) {

        //declare 2 variables

        int numberOne = 356;
        int numberTwo = 356;


        if (numberOne > numberTwo) {
            System.out.println(numberOne + " is greater than " + numberTwo);
        } else if (numberOne < numberTwo) {
            System.out.println(numberOne + " is less than " + numberTwo);
        } else {
            System.out.println(numberOne + " is equal to " + numberTwo);
        }



    }
}
